<?php
/*
* Template Name: New Gallery Page
*/
$postpp = get_option( 'posts_per_page' );
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
get_header('new'); ?>
<link rel="dns-prefetch" href="https://www.gstatic.com">
<link rel="dns-prefetch" href="https://www.googletagmanager.com">
<!--<link rel="dns-prefetch" href="https://fonts.gstatic.com">-->
<link rel="dns-prefetch" href="https://cdn.jsdelivr.net">
<link rel="preload" as="image" href="https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-121-1-1.webp">
<link rel="preconnect" as="font" href="https://www.hushescorts.com.au/wp-content/themes/oceanwp-child/rayligregular-ezpn6-webfont.woff2&display:swap" crossorigin="anonymous">
<link rel="preconnect" as="font" href="https://www.hushescorts.com.au/wp-content/uploads/oceanwp-webfonts/sJoA3LZUhMSAPV_u0qwiAQ-O5Xo.ttf&display:swap" crossorigin="anonymous">
<style>
	@font-face {
    font-family: 'raylig_regularregular';
    src: url('/wp-content/themes/oceanwp-child/rayligregular-ezpn6-webfont.woff2') format('woff2');
    font-weight: normal;
    font-style: normal;
	}
	#main::before {
		content: '';
		position: fixed;
		width: 100%;
		z-index: -1;
		height: 100%;
		background: url(<?php echo get_field('background_hero');?>);
		background-size: cover;
		background-repeat: no-repeat;
		background-position: left bottom;
	}
	@media (max-width: 425px) {
		#main::before {
			background: url(<?php echo get_field('background_hero_mobile');?>);
			position: absolute;
			background-size: cover;
			background-repeat: no-repeat !important;
			background-position: center bottom;
		}		
	}
</style>
<main id="main" class="esgallery site-main clr"<?php oceanwp_schema_markup( 'main' ); ?> role="main"> 
	<?php //do_action( 'ocean_page_header' ); ?>
	<div id="content-wrap" class="container clr">
		<section class="hero">
			<h1 style="font-weight:inherit;">
			<div class="title">
				<?php echo get_field('title_hero');?>
			</div>
			<div class="subtitle" style="font-size:55px;margin: 0 0;">
				<?php echo get_field('subtitle_hero');?>
			</div></h1>
		</section>
	</div>
</main>

<article> 
	<?php //do_action( 'ocean_page_header' ); ?>
	<div id="content-wrap" class="esgallery">
		<section class="h_s6 clr" style="padding: 50px 0;">
			<div class="sl">
				<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="<?php echo get_field('thumbnail_s3');?>" />
			</div>				
			<div class="sr">
				<h3><?php echo get_field('title_s3');?></h3>
				<?php echo get_field('content_s3');?>
			</div>
		</section>	
		<section class="glist clr">	
			<div class="container">
			<?php
			if( have_rows('tabs_s4') ):
				while( have_rows('tabs_s4') ) : the_row();
					$item = get_sub_field('item');
					$term_list = get_the_terms($item, 'ocean_portfolio_category');
					$opc = '';
					echo '
					<div class="item">
						<a href="'.get_the_permalink($item).'">
						'.get_the_post_thumbnail( $item, "full").'
						<h3>'.get_the_title($item).'</h3>
						<p>';
						foreach ( $term_list as $terms) {
							$opc .= $terms->name.', ';
						}
						echo rtrim($opc, ', ');
					echo '
						</p>
						</a>
					</div>
					';					
				endwhile;
			else :
			endif; ?>
			</div>
		</section>	
		<section class="h_s4 clr">	
			<?php 
				if( have_rows('gallery_button_s4') ):
					while ( have_rows('gallery_button_s4') ) : the_row();
						$title = get_sub_field('title');
						$url = get_sub_field('url');
						echo '
						<div class="btn">
						<a href="'.$url.'">'.$title.'</a>
						</div>';
					endwhile;
				else :
					// no rows found
				endif;			
			?>			
		</section>	

		<section class="h_12 clr">			
			<div class="sl">
				<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-66-1.webp" />
			</div>
			<div class="sr">
				<div class="title">
					<h3>Sydney Escort Gallery</h3>
				</div>
				<p><strong>Find Your Perfect Escort with Hush Escorts</strong></p>				
				<p>At Hush Escorts, we understand that our clients have different preferences when it comes to escorts. That’s why we have a wide range of escorts available in our gallery so that you can find the right model escort for you. Whether you’re looking for someone to provide a GFE experience or someone to fulfil your deepest desires, we have a <a href="https://www.hushescorts.com.au/escort-girl-in-sydney/">Sydney escort</a> who can do just that. Simply browse through our escort gallery and find the escort who catches your eye. Then, give us a call, and we’ll arrange everything for you. </p>
			</div>				
		</section>
		
		<section class="h_14 clr">			
			<div class="sl">
				<div class="title">
					<h3>Our NSW Female Escorts</h3>
				</div>			
				<p>At Hush Escorts, only the most experienced ladies in Sydney are employed. We’re confident that we can provide you with an unforgettable experience through not only our escorts’ great looks but their amazing personalities as well. If you book with us, we guarantee that you’ll <a href="https://www.hushescorts.com.au/what-keeps-men-coming-back/">keep coming back</a> and want more!</p>
				<p>You’ll find escorts from all around Australia in our escort gallery who are fun-loving, down to earth and easy to get along with. You’ll feel relaxed and comfortable in their company right away.</p>				
			</div>
			<div class="sr">
				<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-101.png" alt="best escort agency in Sydney" />		
			</div>
			<div class="clearfix"></div>
			<p><strong>Looking for an unforgettable night? </strong></p>
			<p>Our escorts will make sure you have the time of your life. With their seductive looks and sultry moves, they know how to please. Whether you’re looking for a slow and sensual massage or something more adventurous, our  <a href="https://www.hushescorts.com.au/if-you-have-been-looking-for-sydney-escorts-we-can-help/">Sydney escorts</a> will make sure your evening is one to remember.</p>

			<p>We always try to make our customers happy, so if you have any specific requests when booking an escort, don’t hesitate to let us know. We’ll do everything we can to give you an unforgettable experience.</p>		
		</section>

		<section class="h_13 clr">			
			<div class="sl" style="background: url(https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-103.png);">
				<div class="title">
					<h3>How to Find Your Perfect Escort</h3>
				</div>			
				<p>There’s no need to feel rushed. We want you to find the perfect match, so please take your time browsing through our Sydney escorts gallery. Once you’ve found that special someone that catches your eye, give us a call, and we’ll make sure everything is taken care of. We guarantee that your <a href="https://www.hushescorts.com.au/all-you-need-to-know-about-an-escort-date/">escort date</a> will go off without a hitch, leaving you free to relax and enjoy every minute with her.</p>			
			</div>
			<div class="sr" style="background: url(https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-102.png);">
				<div class="title">
					<h3>Why Hush Escorts?</h3>
				</div>			
				<p>At our <a href="https://www.hushescorts.com.au/sydney-escort-agency/" style="color:white;text-decoration:underline;">escort agency</a>, we only hire the most beautiful and talented escorts in Sydney. This way, you can be confident you’re receiving the <a href="https://www.hushescorts.com.au/escort-services/" style="color:white;text-decoration:underline;">best service</a> possible. Furthermore, all of our escorts are professional and discrete. Therefore, your privacy is always guaranteed with us.</p>
			</div>				
		</section>
		
		<section class="h_19 clearboth">
			<div class="title">
				<h3>What our Clients have to Say</h3>
			</div>					
			<div class="content">
				<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />
				<script defer src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
				<div class="swiper mySwiper">
					<div class="swiper-wrapper">
						<div class="swiper-slide">
							<div class="sw_content">
								<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://www.hushescorts.com.au/wp-content/uploads/2023/04/Layer-45.png"/>
								<p>I saw Alana last week, she was so hot- exactly what she looked liked in the photo. She had the best personality and made myself at ease, I will be back again</p>	
								<strong>Tim</strong>								
							</div>
						</div>
						
						<div class="swiper-slide">
							<div class="sw_content">
								<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://www.hushescorts.com.au/wp-content/uploads/2023/04/Layer-45.png"/>
								<p>Jenna is undoubtably the best escort I have ever had. She is travelled and has a worldly personality. We did the girlfriend experience and boy does she know how to get personal and make things real. We will be seeing each other again real soon!</p>	
								<strong>Steve</strong>								
							</div>
						</div>
						<div class="swiper-slide">
							<div class="sw_content">
								<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://www.hushescorts.com.au/wp-content/uploads/2023/04/Layer-45.png"/>
								<p>I had the pleasure of booking the Gorgeous Belle Williams last weekend. We had a great meal at a top restaurant, then back to my room for desert 😉 This girl is so sexy, and so much fun. Cant wait to see her again. Hush is the only escort agency I use in Sydney. Highly recommended.</p>	
								<strong> Hayley H.</strong>								
							</div>
						</div>						
					</div>
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
					<div class="swiper-pagination"></div>
				</div>
			</div>
			<script defer>
				jQuery(document).ready(function($) {
					var swiper = new Swiper(".mySwiper", {
					  navigation: {
						nextEl: ".swiper-button-next",
						prevEl: ".swiper-button-prev",
					  },
					 pagination: {
						el: '.swiper-pagination',
						type: 'bullets',
					  },						
					});
				});
			</script>			
		</section>			
		<section class="cform">
			<div class="container clr">
				<div class="cf_l">
					<h3>Contact Form</h3>
					<?php echo do_shortcode( '[wpforms id="2890"]' ); ?>
				</div>			
				<div class="cf_r">
					<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-104.png">
				</div>
			</div>
		</section>			
	</div>
</article>
<script>
    function init() {
    var imgDefer = document.getElementsByTagName('img');
    for (var i=0; i<imgDefer.length; i++) {
    if(imgDefer[i].getAttribute('data-src')) {
    imgDefer[i].setAttribute('src',imgDefer[i].getAttribute('data-src'));
    } } }
    window.onload = init;
</script>
<?php get_footer('new'); ?>