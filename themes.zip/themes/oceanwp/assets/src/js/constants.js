export const options = oceanwpLocalize;
