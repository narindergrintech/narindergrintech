<?php
/**
 * The Header for our theme.
 *
 * @package OceanWP WordPress theme
 */

?>
<!DOCTYPE html>
<html class="html" lang="en-US">
<head>
	<meta charset="UTF-8">		
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<?php wp_head(); ?>
<!-- Google tag (gtag.js) --> <script src="https://www.googletagmanager.com/gtag/js?id=G-5S37SMPHG4"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-5S37SMPHG4'); </script>
</head>

<body <?php body_class(); ?> <?php oceanwp_schema_markup( 'html' ); ?>>

	<?php wp_body_open(); ?>

	<?php do_action( 'ocean_before_outer_wrap' ); ?>

	<div id="outer-wrap" class="site clr">

		<a class="skip-link screen-reader-text" href="#main"><?php oceanwp_theme_strings( 'owp-string-header-skip-link', 'oceanwp' ); ?></a>

		<?php do_action( 'ocean_before_wrap' ); ?>

		<div id="wrap" class="clr">
			<div class="new_topbar">
			<div class="container">
				<div class="scl">
					<?php
					if( have_rows('social', 'options') ):
						while( have_rows('social', 'options') ) : the_row();
							$twt = get_sub_field('twitter');
							$fb = get_sub_field('facebook');
							$pin = get_sub_field('pinterest');
							$ig = get_sub_field('instagram');
							$ylp = get_sub_field('yellowpages');
							$eml = get_sub_field('email');
						echo '<a href="'.$twt.'"><i class="fab fa-twitter" aria-hidden="true" role="img"></i></a>';
						echo '<a href="'.$fb.'"><i class="fab fa-facebook" aria-hidden="true" role="img"></i></a>';
						echo '<a href="'.$pin.'"><i class="fab fa-pinterest-p" aria-hidden="true" role="img"></i></a>';
						echo '<a href="'.$ig.'"><i class="fab fa-instagram" aria-hidden="true" role="img"></i></a>';
						echo '<a href="'.$ylp.'"><i class="yellowp" aria-hidden="true" role="img"></i></a>';
						echo '<a href="'.$eml.'"><i class="icon-envelopex fa fa-envelope" aria-hidden="true" role="img"></i></a>';
						endwhile;
					else :
					endif;
					?>
				</div>
				<div class="cnt">
					<i class="fab fa-phone" aria-hidden="true" role="img"></i>
					<?php 
					if ( !empty( get_field('phone_contact_1','options') ) ) {
						echo '<a href="tel:'.str_replace(' ','', get_field('phone_contact_1','options').'">'.get_field('phone_contact_1','options')).'</a>';
					}
					echo ' OR ';
					if ( !empty( get_field('phone_contact_2','options') ) ) {
						echo '<a href="tel:'.str_replace(' ','', get_field('phone_contact_2','options').'">'.get_field('phone_contact_2','options')).'</a>';
					}					
					?>
					
					<i class="fab fa-search" aria-hidden="true" role="img"></i>
				</div>
			</div>				
			</div>
			
			
			<?php //do_action( 'ocean_top_bar' ); ?>

			<?php do_action( 'ocean_header' ); ?>

			<?php do_action( 'ocean_before_main' ); ?>