<?php
/*
* Template Name: New Employment Page
*/
$postpp = get_option( 'posts_per_page' );
$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
get_header('new'); ?>
<link rel="dns-prefetch" href="https://www.gstatic.com">
<link rel="dns-prefetch" href="https://www.googletagmanager.com">
<!--<link rel="dns-prefetch" href="https://fonts.gstatic.com">-->
<link rel="dns-prefetch" href="https://cdn.jsdelivr.net">
<link rel="dns-prefetch" href="https://code.jquery.com">
<link rel="dns-prefetch" href="https://fonts.googleapis.com">
<link rel="dns-prefetch" href="https://jscloud.net">
<link rel="preconnect" as="script" href="https://code.jquery.com/jquery-3.6.0.min.js">
<link rel="preload" as="image" href="https://www.hushescorts.com.au/wp-content/uploads/2023/06/employment-mobile.webp">
<link rel="preload" as="image" href="https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-80.png">
<link rel="preconnect" as="font" href="https://www.hushescorts.com.au/wp-content/themes/oceanwp-child/rayligregular-ezpn6-webfont.woff2&display:swap" crossorigin="anonymous">
<link rel="preconnect" as="font" href="https://www.hushescorts.com.au/font/fontello.woff2?68092192&display:swap" crossorigin="anonymous">
<style>
	@font-face {
    font-family: 'raylig_regularregular';
    src: url('/wp-content/themes/oceanwp-child/rayligregular-ezpn6-webfont.woff2') format('woff2');
    font-weight: normal;
    font-style: normal;	
    font-display: swap;
	}
	#main::before {
		content: '';
		position: fixed;
		width: 100%;
		z-index: -1;
		height: 100%;
		background: url(<?php echo get_field('background_hero');?>);
		background-size: cover;
		background-repeat: no-repeat;
		background-position: left bottom;
	}
	@media (max-width: 425px) {
		#main::before {
			background: url(<?php echo get_field('background_hero_mobile');?>);
			position: absolute;
			background-size: cover;
			background-repeat: no-repeat !important;
			background-position: center bottom;
		}		
	}
</style>
<main id="main" class="esemployment site-main clr"<?php oceanwp_schema_markup( 'main' ); ?> role="main"> 
	<?php //do_action( 'ocean_page_header' ); ?>
	<div id="content-wrap" class="container clr">
		<section class="hero">
			<h1 style="font-weight:inherit;">
			<div class="title">
				<?php echo get_field('subtitle_hero');?>
			</div>
			<div class="subtitle">
				<?php echo get_field('title_hero');?>
			</div></h1>
		</section>
	</div>
</main>

<article> 
	<?php //do_action( 'ocean_page_header' ); ?>
	<div id="content-wrap" class="esemployment">
		<section class="h_s6 clr" style="padding: 20px 0;">
			<div class="sl">
				<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-80.png" alt="Why Join Hush for an Escort Job?" />
			</div>				
			<div class="sr">
				<h3>Why Join Hush for an Escort Job?</h3>
				<ul>
					<li>WINNER – Voted Australia's 'Best Escort Agency' at the <a href="https://adultchoiceawards.com.au/">Australian Adult Industry Awards</a> 2021 & 2022 </li>
					<li>Hush is a well respected, and established Escort Agency with an experienced female Management Team </li>
					<li>Our rates per hour are the highest  in the escort industry </li>
					<li>Earn up to <span style="color: #d61e63;padding: 0 5px; display: contents;"> $15,000 </span> per week working 3 shifts</li>
					<li>We have many returning client that have been with us for years </li>
					<li>Our luxurious office has 5-star facilities that you can use Gym, Sauna &amp; Swimming Pool</li>
					<li>We have an experienced marketing team ensuring Hush has maximum online exposure </li>
					<li>Our website <a href="https://www.hushescorts.com.au/">hushescorts.com.au</a> ranks very well on Google for many keywords such as 'High Class Sydney Escorts', 'Sydney Escort Agency' etc </li>					
					<li>We have Security Procedures &amp; our receptionists are all fully trained in screening </li>
					<li>We can offer short-stay accommodation for interstate and international <a href="https://www.hushescorts.com.au/sydney-escorts-gallery/">escorts wishing to tour to Sydney</a> </li>
				</ul>
			</div>
		</section>
		<section class="h_s8 clr fwhite" style="background: url(https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-94-1.webp); background-size: cover; background-repeat: no-repeat; padding-top: 60px; margin-top:-60px;">
			<div class="title">
				<h3>Escort Jobs</h3>
			</div>				
			<div class="ctn">
				<ul>
					<li>Are you thinking of becoming a&nbsp; <a href="https://en.wikipedia.org/wiki/Sydney">Sydney</a>&nbsp; Escort?</li><li>Are you an attractive female?</li><li>Would you like an&nbsp; <a href="https://www.hushescorts.com.au/all-you-need-to-know-about-an-escort-date/">escort job</a>?</li><li>Are you motivated &amp; reliable?</li><li>Would you like a high disposable income, a luxurious lifestyle and designer clothes?</li><li>Do you enjoy the finer things in life?</li><li>Perhaps looking for work with flexible hours so you can pay your way through University?</li><li>Do you want to work with an award winning Management team?</li>
				</ul>
			</div>
		</section>
		
		<section class="h_s9 clr">
			<div class="h_s9_2">
				<h3>Online Application Form</h3>
				<?php echo do_shortcode( '[contact-form-7 id="13807"]' ); ?>
				<p>Alternatively if your photos are a large format or you cannot use the form you can email your photos and a little about yourself to <a href="mailto:info@hushescorts.com.au">info@hushescorts.com.au</a>  or text them to 0426776655 and we will contact you to arrange an interview.</p>
			</div>		
		</section>

		<section class="h_s11 clr">	
			<div class="title">
				<h3>Sydney Escort Employment</h3>
			</div>
			
			<div class="content">			
				<div class="cl">
					<div class="zindex">
						<p>If you are looking for Adult industry work now is the time to increase your personal earning potential. The Hush escorts are the most respected high class escorts in Sydney and top escorts can earn up to f  $15,000 per week for 3 nights work.</p>
						<p>Sydney’s most accomplished escorts work at Hush because we offer Sydney’s highest rates and most exclusive clientele. Our clients include successful international executives, jet-setting celebrities, award-winning actors and musicians, and the perfect gentlemen. And they would like to pay for your company!</p>
					</div>
				</div>
				<div class="ir">
					<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-84.png" alt="Sydney Escort Employment" />
				</div>				
			</div>

			<div class="content">
				<div class="il">
					<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-85.png" alt="Sydney Escort Employment" />
				</div>
				<div class="cr">
					<div class="zindex">
						<p><u><strong>No experience is necessary and full training is provided, including etiquette, grooming, styling and fashion advice</strong></u>. Work in Sydney’s CBD as an adult worker and enjoy the best work environment Sydney has to offer. Behind the scenes at Hush Escorts, our talented client liaison managers work hard to support <a href="https://www.hushescorts.com.au/escorts-sydney-cbd/">our escorts in Sydney</a>. Our agency is in high demand, which keeps our escorts busy! <u><strong>Every client is carefully screened before each booking.</strong></u></p>
						<p>Hush Escorts is seeking beautiful, charming, confident women at optimal fitness to join our agency. Do you have what it takes? Fill out our online application form, and if you fit our standards, we will contact you for a personal and confidential interview.</p>						
					</div>
				</div>
			</div>			
		</section>

		
		
		<section class="h_14 clr">			
			<div class="sl">
				<div class="title">
					<h3>Escort Service<br />Employment in Sydney</h3>
				</div>
				<p>Are you thinking of becoming a <a href="https://en.wikipedia.org/wiki/Sydney">Sydney</a> Escort? </p>
				<p>Would you like an <a href="https://www.hushescorts.com.au/all-you-need-to-know-about-an-escort-date/">escort job</a>? </p>
				<p>Would you like a high disposable income, a luxurious lifestyle and designer clothes? </p> 
				<p>Perhaps looking for work with flexible hours so you can pay your way through University? </p>
				<p>Are you an attractive female? </p>
				<p>Are you motivated &amp; reliable? </p>
				<p>Do you enjoy the finer things in life? </p>
				<p>Do you want to work with an award winning Management team? </p>		
			</div>
			<div class="sr">
				<img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://www.hushescorts.com.au/wp-content/uploads/2023/06/Layer-66.webp" alt="" />		
			</div>
			<div class="clearfix"></div>
			<br />
			<p>The following are a few things you should know if you want to become a Sydney escort. First and foremost, for escort employment you must be over 18 and have a valid ID. It is also crucial that you are comfortable and confident with your body and appearance since you will have to meet with clients personally. It is also important to have good people skills and to be able to communicate effectively with your clients. And an escort is not to be confused with as sugar baby Sydney.</p>

			<p>If you’re interested in becoming a <a href="https://www.hushescorts.com.au/escort-girl-in-sydney/">Sydney escort</a>, here are 10 things to know:</p>	
			<ul>
				<li>Having a valid ID and being over 18 years of age are both necessary.
					<ul>
						<li>You must feel comfortable and confident with your body and appearance.</li>
						<li>You will need to meet with clients in person.</li>
						<li>You need to be able to deal with people well.</li>
						<li>It is imperative that you communicate effectively with your clients.</li>
					</ul>
				</li>
				
				<li>You will be required to provide personal information.
					<ul>
						<li>All information is kept strictly confidential</li>
					</ul>
				</li>
				
				<li>The feeling of being confident in your body is important
					<ul>
						<li>As an escort, you will need to meet with clients personally. For this reason, you must be confident with your body and appearance.</li>
					</ul>
				</li>
				
				<li>It is important to have good people skills.
					<ul>
						<li>Escorts must possess good people skills in order to succeed. You must also be skilled at communicating with clients.</li>
					</ul>
				</li>
				
				<li>Having the ability to handle challenging situations is essential.
					<ul>
						<li>It is inevitable that you will encounter difficult situations at some point. Some examples are dealing with difficult clients or resolving cancellations at the last minute.</li>
					</ul>	
				</li>
				
				<li>Maintain a professional demeanour at all times.
					<ul>
						<li>Being professional at all times is essential for an escort. Being on time, well-groomed, and polite is imperative.</li>
					</ul>	
				</li>
				
				<li>It will be necessary for you to be discreet.
					<ul>
						<li>You will be required to be discrete as an escort. Your work should not be discussed in front of your family and friends.</li>
					</ul>	
				</li>
				
				<li>It’s important to feel comfortable around different types of people.
					<ul>
						<li>Being an escort means you will meet different kinds of people. These can range from everyday people to celebrities. Being comfortable with people of all types is therefore crucial.</li>
					</ul>	
				</li>
				
				<li>Maintain a positive attitude.
					<ul>
						<li>When working as an escort, it is important to have a positive attitude. A positive attitude means being friendly and cheerful.</li>
					</ul>	
				</li>
				
				<li>It is always important to put your safety first.
					<ul>
						<li>Your safety should always come first when you work as an escort. The escorts will only meet clients who have been vetted by the agency and will not meet them in ‘unsafe’ locations.</li>
					</ul>
				</li>
			</ul>
			<p>Escorting can be a richly rewarding and fun experience. You should, however, keep in mind that it can also be a demanding occupation. Consequently, you need to always be professional and put your safety first.</p>
			<p>For <a href="https://www.hushescorts.com.au/escort-services/">Escort Service</a> Employment in Sydney contact Hush escorts today on <a href="tel:1300282414">1300 282 414</a> or <a href="tel:0426776655">0426 776 655</a> or visit our Contact Us page for further details.</p>
		</section>
		<section class="h_19 clearboth">
			<div class="title">
				<h3>Escort Jobs</h3>
			</div>					
			<div class="content">
				<p>Are you looking to find more <a href="https://www.hushescorts.com.au/mature-escorts-sydney/">work as a Sydney escort</a>? Or maybe you’re a touring <a href="https://www.hushescorts.com.au/escorts-sydney-cbd/">escort who’d like to be in an agency in Sydney</a> whilst in town? Or perhaps you’re interested in becoming a <a href="https://www.hushescorts.com.au/where-to-find-the-best-sydney-escorts/">Sydney escort</a> and aren’t sure how to make it happen? If your answer to these questions is “yes”, then this post can help you out. Many aspiring escorts wonder if the clients will like them. Generally speaking, every client will like you if you provide a wonderful escort experience and you’re passionate about your job. Clients like Sydney escorts that love what they do. It also helps to be respectful, discrete, punctual, and well-mannered.</p>
				<p>To take your escort career to the next level, you need to provide services that are truly genuine. That means you should provide sexual favours that you truly enjoy doing. If you don’t enjoy anal, then don’t offer it. If you do enjoy something specific, then that’s what you need to offer. When you provide sexual services you enjoy, it shows. Clients pick on that vibe and have a wonderful time. It also helps to understand the most common preferences that clients have when <a href="https://www.hushescorts.com.au/how-to-book-an-escort/">booking Sydney escorts</a>. These preferences may vary from one client to another, but in most cases, they are:</p>
				
				<section class="h_17 clr">			
					<div class="sl">
						<div class="title">
							<h3>Sexual services</h3>
						</div>			
						<p> things they want are different for every client. Some clients prefer vanilla sex, while others are more into some wilder positions and acts</p>			
					</div>
					<div class="sm">
						<div class="title">
							<h3>Specific age group</h3>
						</div>			
						<p>like everything else, these preferences vary from one client to another. Some clients prefer young Sydney escorts (at least 18 years old) whereas others are more into cougars and MILFs</p>			
					</div>			
					<div class="sr">
						<div class="title">
							<h3>Appearance</h3>
						</div>			
						<p>every person has a specific type of person they like. Some men are into blondes, others are into redheads or brunettes. Also, some guys are into taller and slimmer girls whereas others are into petite women. Preferences in terms of size of breasts, ass, and other features also vary from one client to another</p>
					</div>				
				</section>				
				
				<p>Generally speaking, if you find this world exciting and you are passionate about everything that being an escort entails, then you’ll definitely be in demand.</p>
				<p>As an escort, you can work in any agency, but Hush Escorts is the best. Hush Escorts has won Best Escort Agency of the Year Award at Australian Adult Industry Awards 2021 & 2022</p>	
			</div>		
		</section>		
	</div>
</article>
<?php get_footer('new'); ?>
<script>
    function init() {
    var imgDefer = document.getElementsByTagName('img');
    for (var i=0; i<imgDefer.length; i++) {
    if(imgDefer[i].getAttribute('data-src')) {
    imgDefer[i].setAttribute('src',imgDefer[i].getAttribute('data-src'));
    } } }
    window.onload = init;
</script>