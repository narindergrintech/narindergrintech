<?php

function oceanwp_child_enqueue_parent_style() {
	$theme   = wp_get_theme( 'OceanWP' );
	$version = $theme->get( 'Version' );

	// Load the stylesheet.
	wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'oceanwp-style' ), $version );
	wp_enqueue_style( 'child-style-min', get_stylesheet_directory_uri() . '/assets/css/style.min.css', array( 'oceanwp-style-min' ), $version );
}
add_action( 'wp_enqueue_scripts', 'oceanwp_child_enqueue_parent_style' );

/**
 * Add mime type
 *
 * @see https://developer.wordpress.org/reference/hooks/upload_mimes/
 */
function barrd_enable_avif_mime( $mimes ) {
	$mimes['avif'] = 'image/avif';

	return $mimes;
}
add_filter( 'upload_mimes', 'barrd_enable_avif_mime' );

// New ACF Menu
add_action('admin_menu', 'admin_panel');
 function admin_panel()
 {
	 add_menu_page('ThemeSettings', 'ACF Pages', 'manage_options', 'Theme Panel', 'page link', 'dashicons-admin-page', 10);
}

add_action('admin_menu', 'admin_panel_menu');
function admin_panel_menu()
{
	global $submenu;
	$submenu['Theme Panel'][0] = array( 'Homepage', 'manage_options', "/wp-admin/post.php?post=13102&action=edit&lang=en");
    $submenu['Theme Panel'][1] = array(  'Gallery', 'manage_options', "/wp-admin/post.php?post=10394&action=edit");
	$submenu['Theme Panel'][2] = array(  'Employment', 'manage_options', "/wp-admin/post.php?post=13457&action=edit");
	$submenu['Theme Panel'][3] = array(  'Portfolio', 'manage_options', "https://www.hushescorts.com.au/wp-admin/edit.php?post_type=ocean_portfolio");
	
}

function shapeSpace_disable_scripts_styles_admin_area() {	
	wp_dequeue_style('jquery-ui-css');	
}
add_action('admin_enqueue_scripts', 'shapeSpace_disable_scripts_styles_admin_area', 100);

//Disable XML-RPC
add_filter('xmlrpc_enabled', '__return_false');

// REMOVE EMOJI ICONS
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');

function dequeue_jquery_migrate( $scripts ) {
	if ( ! is_admin() && ! empty( $scripts->registered['jquery'] ) ) {
		$scripts->registered['jquery']->deps = array_diff(
			$scripts->registered['jquery']->deps,
			[ 'jquery-migrate' ]
		);
	}
}
add_action( 'wp_default_scripts', 'dequeue_jquery_migrate' );

// Remove version entirely from the source files
function sh_remove_ver_css_js( $src_file ) {
	if ( strpos( $src_file, 'ver=' ) )
		$src_file = remove_query_arg( 'ver', $src_file );
	return $src_file;
}
add_filter( 'style_loader_src', 'sh_remove_ver_css_js', 9999 );
add_filter( 'script_loader_src', 'sh_remove_ver_css_js', 9999 );

// remove Really Simple Discovery, Windows Live Writer,  WordPress version number, Post relational links, Feeds
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'start_post_rel_link' );
remove_action( 'wp_head', 'parent_post_rel_link' );
remove_action( 'wp_head', 'index_rel_link' );
remove_action( 'wp_head', 'adjacent_posts_rel_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
remove_action( 'wp_head', 'feed_links' ); 
remove_action( 'wp_head', 'feed_links_extra' );



add_action('wp_print_scripts', function () {
	global $post;
	if ( is_a( $post, 'WP_Post' ) && !has_shortcode( $post->post_content, 'contact-form-7') ) {
		wp_dequeue_script( 'google-recaptcha' );
		wp_dequeue_script( 'wpcf7-recaptcha' );
	}
});

add_filter( 'use_widgets_block_editor', '__return_false' );

//Remove Gutenberg Block Library CSS from loading on the frontend
function smartwp_remove_wp_block_library_css(){
 wp_dequeue_style( 'wp-block-library' );
 wp_dequeue_style( 'wp-block-library-theme' );
}
add_action( 'wp_enqueue_scripts', 'smartwp_remove_wp_block_library_css' );

add_filter('use_block_editor_for_post', '__return_false', 10);